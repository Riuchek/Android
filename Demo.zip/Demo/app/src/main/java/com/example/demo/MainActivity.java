package com.example.demo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Logar(View view){
        Login login = new Login();
        try {
            EditText editUsuario = findViewById(R.id.editUsuario);
            EditText editSenha = findViewById(R.id.editSenha);
            String usuario = editUsuario.getText().toString();
            String senha = editSenha.getText().toString();
            if (login.isValid(usuario,senha)){
                startActivity(new Intent(this,MenuActivity.class));
            }
            else{
                Toast.makeText(this,"Incorreto",Toast.LENGTH_LONG);
            }



        }catch (Exception error1){
            Toast.makeText(this,"Erro ao inserir os dados",Toast.LENGTH_LONG);
        }

    }
}