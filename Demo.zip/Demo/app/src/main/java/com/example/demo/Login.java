package com.example.demo;

public class Login {
    private static final  String USUARIO="fatec";
    private static final  String SENHA="mococa";



    public Boolean isValid(String usuario, String senha){
       if (usuario.equals(USUARIO)&&senha.equals(SENHA)){
           return true;
       }
       else
       {
           return false;

       }
    }
}
