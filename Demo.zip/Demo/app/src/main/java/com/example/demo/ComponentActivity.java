package com.example.demo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.sql.Array;
import java.util.ArrayList;
import java.util.List;

public class ComponentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_component);
        CarregarSpinnerProdutos();
    }

    private void CarregarSpinnerProdutos(){


        Spinner spinnerProdutos = findViewById(R.id.spinnerProdutos);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
        adapter.add("TV");
        adapter.add("Geladeira");
        adapter.add("Celulinho");
        adapter.add("Xbox Series X");
        spinnerProdutos.setAdapter(adapter);
    }

    private List<Produto> gerarListaProdutos(){
        Produto p1 = new Produto();
        List<Produto> listaProdutos = new ArrayList<Produto>();
        for (int i = 0; i < 5; i++) {
            p1.setCodigo(i);
            p1.setNome("TV "+i);
            p1.setValor((20.55*i+10.00));
            listaProdutos.add(p1);
        }
        return listaProdutos;
    }

    public void confirmarProduto(View view){
        Spinner spinnerProdutos = findViewById(R.id.spinnerProdutos);
        Toast.makeText(this,spinnerProdutos.getSelectedItem().toString(),Toast.LENGTH_LONG).show();
    }
}